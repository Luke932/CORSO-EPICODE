alert('Usa il pop up per dare dei messaggi');
window.alert('Sto studiando JS');