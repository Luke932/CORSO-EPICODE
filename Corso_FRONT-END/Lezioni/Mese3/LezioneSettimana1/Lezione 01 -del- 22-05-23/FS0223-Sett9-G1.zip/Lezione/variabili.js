console.log('Hello World!');
let nome = 'Mario';
console.log(`Il tuo nome è ${nome}`);
let verifica = 5 < 3 ? true : false;
console.log(verifica);
for (let i = 0; i < 5; i++) {
    console.log(i);
}
let sconosciuto;
sconosciuto = "nome";
console.log(sconosciuto);
sconosciuto = 15;
console.log(sconosciuto);
let dedotto = [1, 2, 3, 4, 5];
console.log(typeof dedotto);
let costruito = new String('pippo');
let copiato = costruito;
console.log(copiato);
