enum Mesi {
    gennaio = 1,
    febbraio,
    marzo,
    aprile,
    maggio,
    giugno,
    luglio,
    agosto,
    settembre,
    ottobre,
    novembre,
    dicembre
}

console.log(Mesi.giugno);